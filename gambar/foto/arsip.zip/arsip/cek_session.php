<?php
include "koneksi.php";
if(!isset($_SESSION)){
	session_start();
}
$user=$_SESSION['username'];
$pass=$_SESSION['password'];
$query=mysql_query(" SELECT * from user where username='$_SESSION[username]' and password='$_SESSION[password]' ");
$cek=mysql_num_rows($query);
if($cek>=1){
	return TRUE;
	exit();
}else{
	header('location:index.php?info_e=anda tidak berhak mengakses laman ini');
}
