<?php 
session_start(); 
if ($_SESSION['level']=="admin") {
include 'koneksi.php';
$id=$_GET['id'];
$query_hapus=mysql_query("DELETE FROM surat_masuk where id_surat='$id' ");
if (!$query_hapus) {
	# code...
	header("location:home.php?page=surat_masuk&info_s=Hapus Surat Masuk gagal");
}else{
	header("location:home.php?page=surat_masuk&info_s=Hapus Surat Masuk Berhasil");
}
}else{
	echo "<script>alert('Anda Tidak Berhak Mengakses Laman Ini'); window.location = 'home.php'</script>";
}

 ?>