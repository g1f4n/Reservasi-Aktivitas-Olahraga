<?php 
				if ($_SESSION['level']=="admin") {
					# code...
					$id=$_GET['id'];
					$detail_pegawai=mysql_query("SELECT * FROM pegawai where id_pegawai='$id'");
					$data_pegawai=mysql_fetch_array($detail_pegawai);
				?>

<div class="breadcrumbs" id="breadcrumbs">
  <ul class="breadcrumb">
    <li> <i class="icon-home home-icon"></i> <a href="home.php?page=pegawai">Pegawai</a> <span class="divider"> <i class="icon-angle-right arrow-icon"></i> </span> </li>
    <li class="active">Pegawai</li>
  </ul>
  <!--.breadcrumb--> 
</div>
<div class="page-content">
  <div class="page-header position-relative">
    <h1> Pegawai <small> <i class="icon-double-angle-right"></i> Edit Pegawai </small> </h1>
  </div>
  <!--/.page-header-->
  <div class="login-container">
    <?php 
			if(isset($_GET['info_e'])){
			$display="block";
			$pemberitahuan=$_GET['info_e'];
		}else{
			$display="none";
			$pemberitahuan="";
}
?>
    <div class="alert alert-danger" style="display:<?php echo $display;?>;"><?php echo $pemberitahuan; ?>
      <button class="close" data-dismiss="alert">&times;</button>
    </div>
  </div>

  <div class="row-fluid">
    <div class="span12"> 
      <!--PAGE CONTENT BEGINS-->
       <form class="form-horizontal" method="POST" action="aksi_tambah_pegawai.php" enctype="multipart/form-data" />
      <div class="control-group">
        <label class="control-label">NIP</label>
        <div class="controls">
        <input type="hidden" name="uid" value="<?php echo $id; ?>" />
          <input class="input-xxlarge" type="text"  name="unip" value="<?php echo $data_pegawai['nip']; ?>"  />
        </div>
      </div>
      <div class="control-group">
        <label class="control-label">nama</label>
        <div class="controls">
          <input class="input-xxlarge" type="text"  name="unama" value="<?php echo $data_pegawai['nama']; ?>" />
        </div>
      </div>
      <div class="control-group">
        <label class="control-label">Gender</label>
        <div class="controls">
        <input class="input-xxlarge" type="text"  name="ugender" value="<?php echo $data_pegawai['gender']; ?>"\/>
        </div>
      </div>
      <div class="control-group">
        <label class="control-label">Alamat</label>
        <div class="controls">
          <textarea class="wysiwyg-editor input-xxlarge" name="ualamat" ><?php echo $data_pegawai['alamat']; ?></textarea>
        </div>
      </div>
      <div class="control-group">
        <label class="control-label">Telepon</label>
        <div class="controls">
        <input class="input-xxlarge" type="text"  name="utelepon" value="<?php echo $data_pegawai['telepon']; ?>" />
        </div>
      </div>
        <div class="form-actions">
        <button class="btn btn-info" name="usubmit" type="usubmit"> <i class="icon-ok bigger-110"></i> Submit </button>
        &nbsp; &nbsp; &nbsp;
        <button class="btn" type="reset"> <i class="icon-undo bigger-110"></i> Reset </button>
        &nbsp; &nbsp; &nbsp;
        <a class="btn" href="home.php?page=pegawai"> <i class=" bigger-110"></i> Kembali </a>
      </div>
       </form>
      </div>
    <!--/.span--> 
  </div>
  <!--/.row-fluid--> 
</div>
<!--/.page-content-->

<?php 
				}
				else{
  				echo "<script>alert('Anda Tidak Berhak Mengakses Laman Ini'); window.location = 'home.php'</script>";
				}

				 ?>
