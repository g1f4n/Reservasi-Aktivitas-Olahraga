<?php
session_start(); 
if ($_SESSION['level']=="admin") {
	if (isset($_POST['submit'])!="" and $_POST['no_surat']!="" and $_POST['uraian']!="" and $_POST['ket']!="" and $_POST['tanggal']!="") {
		# code...
		include 'koneksi.php';
		$no_surat=$_POST['no_surat'];
		$uraian=$_POST['uraian'];
		$ket=$_POST['ket'];
		$tanggal=$_POST['tanggal'];
		$query_tambah=mysql_query("INSERT INTO surat_masuk(nomor_surat,uraian,ket,tanggal)
		VALUES ('$no_surat','$uraian','$ket','$tanggal')");
		header('location:home.php?page=surat_masuk&info_s=tambah surat Masuk Berhasil');
	}elseif (isset($_POST['usubmit'])!="" and $_POST['uno_surat']!="" and $_POST['uuraian']!="" and $_POST['uket']!="" and $_POST['utanggal']!="") {
		# code...
		include 'koneksi.php';
		$uid=$_POST['uid'];
		$uno_surat=$_POST['uno_surat'];
		$uuraian=$_POST['uuraian'];
		$uket=$_POST['uket'];
		$utanggal=$_POST['utanggal'];
		$query_update=mysql_query("UPDATE surat_masuk SET nomor_surat='$uno_surat',uraian='$uuraian',ket='$uket',tanggal='$utanggal' where id_surat='$uid' ");
		header('location:home.php?page=surat_masuk&info_s=Update surat Masuk Berhasil');
	}elseif (isset($_POST['usubmit'])) {
		# code...
		$uid=$_POST['uid'];
		header("location:home.php?page=edit_surat_masuk&id=$uid&info_e=Data Yang Anda input Tidak Lengkap");
	}
	else{
		header('location:home.php?page=tambah_surat_masuk&info_e=Data Yang Anda input Tidak Lengkap');
	}

	}else{
  				echo "<script>alert('Anda Tidak Berhak Mengakses Laman Ini'); window.location = 'home.php'</script>";
	}

 ?>