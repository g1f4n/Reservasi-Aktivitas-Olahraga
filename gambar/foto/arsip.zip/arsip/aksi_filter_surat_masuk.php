<?php 
if (isset($_POST['submit'])!="" and $_POST['dari']!="" and $_POST['sampai']!="") {
	# code...
	$dari=$_POST['dari'];
	$sampai=$_POST['sampai'];
	header("location:home.php?page=surat_masuk&dari=$dari&sampai=$sampai");
}else{
	header('location:home.php?page=surat_masuk&info_e=Data Yang Anda input Tidak Lengkap');
}

 ?>