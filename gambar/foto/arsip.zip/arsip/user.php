<?php 
				if ($_SESSION['level']=="admin") {
					# code...
				?>

<div class="breadcrumbs" id="breadcrumbs">
  <ul class="breadcrumb">
    <li> <i class="icon-home home-icon"></i> <a href="home.php?page=user">User</a> <span class="divider"> <i class="icon-angle-right arrow-icon"></i> </span> </li>
    <li class="active">User</li>
  </ul>
  <!--.breadcrumb--> 
</div>
<div class="page-content">
  <div class="page-header position-relative">
    <h1> User <small> <i class="icon-double-angle-right"></i> View </small> </h1>
  </div>
  <!--/.page-header-->
  <div class="login-container">
    <?php 
if(isset($_GET['info_s'])){
	$display="block";
	$pemberitahuan=$_GET['info_s'];
}else{
	$display="none";
	$pemberitahuan="";
}
?>
    <div class="alert alert-success" style="display:<?php echo $display;?>;"><?php echo $pemberitahuan; ?>
      <button class="close" data-dismiss="alert">&times;</button>
    </div>
  </div>
  <a href="home.php?page=tambah_user">
  <button class="btn btn-primary">Tambah User</button>
  </a> <br>
  <br>
  <div class="row-fluid">
    <div class="span12"> 
      <!--PAGE CONTENT BEGINS-->
      
      <div class="row-fluid">
        <div class="table-header"> Daftar user </div>
        <table id="sample-table-2" class="table table-striped table-bordered table-hover">
          <thead>
            <tr>
              <th class="center" style="width:1px;"></th>
              <th>NO</th>
              <th>Nama</th>
              <th>Username</th>
              <th class="hidden-480">Alamat</th>
              <th>Level</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <?php 
									$query_user=mysql_query("SELECT * FROM user order by nama_user ASC");
									$no=1;
									while ($data_user=mysql_fetch_array($query_user)) {
										# code...
										echo '<tr>
											<td class="center"></td>
											<td>'; echo $no; echo '</td>

											<td>
												';echo $data_user['nama_user'];echo '
											</td>
											<td>
												';echo $data_user['username'];echo'
											</td>
											<td class="hidden-480">
												';echo $data_user['alamat'];echo'
											</td>

											<td >
												';echo $data_user['level'];echo'
											</td>

											<td class="td-actions">
												<div class="hidden-phone visible-desktop action-buttons">
													

													<a class="red" href="hapus_user.php?id=';echo $data_user['id_user'] ;echo'">
														<i class="icon-trash bigger-130"></i>
													</a>
												</div>

												<div class="hidden-desktop visible-phone">
													<div class="inline position-relative">
														<button class="btn btn-minier btn-yellow dropdown-toggle" data-toggle="dropdown">
															<i class="icon-caret-down icon-only bigger-120"></i>
														</button>
														<ul class="dropdown-menu dropdown-icon-only dropdown-yellow pull-right dropdown-caret dropdown-close">

															<li>
																<a href="hapus_user.php?id=';echo $data_user['id_user'] ;echo'" class="tooltip-error" data-rel="tooltip" title="Delete">
																	<span class="red">
																		<i class="icon-trash bigger-120"></i>
																	</span>
																</a>
															</li>
														</ul>
													</div>
												</div>
											</td>
										</tr>';
										$no++;
									}
									 ?>
          </tbody>
        </table>
      </div>
      
      <!--PAGE CONTENT ENDS--> 
    </div>
    <!--/.span--> 
  </div>
  <!--/.row-fluid--> 
</div>
<!--/.page-content--> 
<!--basic scripts--> 

<!--[if IE]>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<![endif]--> 

<!--[if !IE]>--> 

<script type="text/javascript">
			window.jQuery || document.write("<script src='assets/js/jquery-2.0.3.min.js'>"+"<"+"/script>");
		</script> 

<!--<![endif]--> 

<!--[if IE]>
<script type="text/javascript">
 window.jQuery || document.write("<script src='assets/js/jquery-1.10.2.min.js'>"+"<"+"/script>");
</script>
<![endif]--> 

<!--page specific plugin scripts--> 

<script src="assets/js/jquery.dataTables.min.js"></script> 
<script src="assets/js/jquery.dataTables.bootstrap.js"></script> 

<!--ace scripts--> 

<!--inline scripts related to this page--> 

<script type="text/javascript">
			$(function() {
				var oTable1 = $('#sample-table-2').dataTable( {
				"aoColumns": [
			      { "bSortable": false },
			      null, null,null, null, null,
				  { "bSortable": false }
				] } );
				
				
				$('table th input:checkbox').on('click' , function(){
					var that = this;
					$(this).closest('table').find('tr > td:first-child input:checkbox')
					.each(function(){
						this.checked = that.checked;
						$(this).closest('tr').toggleClass('selected');
					});
						
				});
			
			
				$('[data-rel="tooltip"]').tooltip({placement: tooltip_placement});
				function tooltip_placement(context, source) {
					var $source = $(source);
					var $parent = $source.closest('table')
					var off1 = $parent.offset();
					var w1 = $parent.width();
			
					var off2 = $source.offset();
					var w2 = $source.width();
			
					if( parseInt(off2.left) < parseInt(off1.left) + parseInt(w1 / 2) ) return 'right';
					return 'left';
				}
			})
		</script>
<?php 
				}else{
  				echo "<script>alert('Anda Tidak Berhak Mengakses Laman Ini'); window.location = 'home.php'</script>";
				}

				 ?>
