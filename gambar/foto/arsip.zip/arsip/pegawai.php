<?php 
if ($_SESSION['level']=="admin") {
	# code...
	?>
	<div class="breadcrumbs" id="breadcrumbs">
					<ul class="breadcrumb">
						<li>
							<i class="icon-home home-icon"></i>
							<a href="home.php?page=pegawai">Pegawai</a>

							<span class="divider">
								<i class="icon-angle-right arrow-icon"></i>
							</span>
						</li>
						<li class="active">Pegawai</li>
					</ul><!--.breadcrumb-->
				</div>
				<div class="page-content">
					<div class="page-header position-relative">
						<h1>
							Pegawai
							<small>
								<i class="icon-double-angle-right"></i>
								View
							</small>
						</h1>
					</div><!--/.page-header-->
						<div class="login-container">
			<?php 
if(isset($_GET['info_s'])){
	$display="block";
	$pemberitahuan=$_GET['info_s'];
}else{
	$display="none";
	$pemberitahuan="";
}
?>
<div class="alert alert-success" style="display:<?php echo $display;?>;"><?php echo $pemberitahuan; ?>
<button class="close" data-dismiss="alert">&times;</button>
</div>
</div>	<div class="form-inline">
					<a href="home.php?page=tambah_pegawai"><button class="btn btn-primary">Tambah Pegawai</button></a>
					<a href="export_pegawai.php"><button class="btn btn-primary">Export pegawai</button></a>
					</div>
					<div class="row-fluid">

						<div class="span12">
							<!--PAGE CONTENT BEGINS-->
						
							<br>
									
							<div class="row-fluid">
								<div class="table-header">
									Data Pegawai
								</div>

								<table id="sample-table-2" class="table table-striped table-bordered table-hover">
									<thead>
										<tr>
											<th class="center" style="width:1px;">NO</th>
											<th style="width:5px;">NIP</th>
											<th>Nama</th>
											<th >Gender</th>
											<th class="hidden-480">Alamat</th>
											<th class="hidden-480">Telepon</th>
											<th></th>
										</tr>
									</thead>
									<tbody>
									<?php 
									
									$query_pegawai=mysql_query("SELECT * FROM pegawai order by nama ASC");
									
									$no=1;
									while ($data_pegawai=mysql_fetch_array($query_pegawai)) {
										# code...
										echo '<tr>
											<td class="center">';echo  $no; echo'</td>
											<td>'; echo $data_pegawai['nip']; echo '</td>

											<td>
												';echo $data_pegawai['nama'];echo '
											</td>
											<td >
												';echo $data_pegawai['gender'];echo'
											</td>
											<td class="hidden-480">
												';echo $data_pegawai['alamat'];echo'
											</td>

											<td class="hidden-480">
												';echo $data_pegawai['telepon'];echo'
											</td>

											<td class="td-actions">
												<div class="hidden-phone visible-desktop action-buttons">
													<a class="blue" href="home.php?page=detail_pegawai&id=';echo  $data_pegawai['id_pegawai'] ;echo'">
														<i class="icon-zoom-in bigger-130"></i>
													</a>

													<a class="green" href="home.php?page=edit_pegawai&id=';echo  $data_pegawai['id_pegawai'] ;echo'">
														<i class="icon-pencil bigger-130"></i>
													</a>

													<a class="red" href="hapus_pegawai.php?id=';echo $data_pegawai['id_pegawai'] ;echo'">
														<i class="icon-trash bigger-130"></i>
													</a>
												</div>

												<div class="hidden-desktop visible-phone">
													<div class="inline position-relative">
														<button class="btn btn-minier btn-yellow dropdown-toggle" data-toggle="dropdown">
															<i class="icon-caret-down icon-only bigger-120"></i>
														</button>
														<ul class="dropdown-menu dropdown-icon-only dropdown-yellow pull-right dropdown-caret dropdown-close">
															<li>
																<a href="home.php?page=detail_pegawai&id=';echo  $data_pegawai['id_pegawai'] ;echo'" class="tooltip-info" data-rel="tooltip" title="View">
																	<span class="blue">
																		<i class="icon-zoom-in bigger-120"></i>
																	</span>
																</a>
															</li>

															<li>
																<a href="home.php?page=edit_pegawai&id=';echo  $data_pegawai['id_pegawai'] ;echo'" class="tooltip-success" data-rel="tooltip" title="Edit">
																	<span class="green">
																		<i class="icon-edit bigger-120"></i>
																	</span>
																</a>
															</li>
															<li>
																<a href="hapus_pegawai.php?id=';echo $data_pegawai['id_pegawai'] ;echo'" class="tooltip-error" data-rel="tooltip" title="Delete">
																	<span class="red">
																		<i class="icon-trash bigger-120"></i>
																	</span>
																</a>
															</li>
														</ul>
													</div>
												</div>
											</td>
										</tr>';
										$no++;
									}
									 ?>
									</tbody>
								</table>
							</div>

							
									
								
							<!--PAGE CONTENT ENDS-->
						</div><!--/.span-->
					</div><!--/.row-fluid-->
				</div><!--/.page-content--> 
<!--basic scripts--> 

<!--[if IE]>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<![endif]--> 

<!--[if !IE]>--> 

<script type="text/javascript">
			window.jQuery || document.write("<script src='assets/js/jquery-2.0.3.min.js'>"+"<"+"/script>");
		</script> 

<!--<![endif]--> 

<!--[if IE]>
<script type="text/javascript">
 window.jQuery || document.write("<script src='assets/js/jquery-1.10.2.min.js'>"+"<"+"/script>");
</script>
<![endif]--> 

<!--page specific plugin scripts--> 

<script src="assets/js/jquery.dataTables.min.js"></script> 
<script src="assets/js/jquery.dataTables.bootstrap.js"></script> 

<!--ace scripts--> 

<!--inline scripts related to this page--> 

<script type="text/javascript">
			$(function() {
				var oTable1 = $('#sample-table-2').dataTable( {
				"aoColumns": [
			      { "bSortable": false },
			      null, null,null, null, null,
				  { "bSortable": false }
				] } );
				
				
				$('table th input:checkbox').on('click' , function(){
					var that = this;
					$(this).closest('table').find('tr > td:first-child input:checkbox')
					.each(function(){
						this.checked = that.checked;
						$(this).closest('tr').toggleClass('selected');
					});
						
				});
			
			
				$('[data-rel="tooltip"]').tooltip({placement: tooltip_placement});
				function tooltip_placement(context, source) {
					var $source = $(source);
					var $parent = $source.closest('table')
					var off1 = $parent.offset();
					var w1 = $parent.width();
			
					var off2 = $source.offset();
					var w2 = $source.width();
			
					if( parseInt(off2.left) < parseInt(off1.left) + parseInt(w1 / 2) ) return 'right';
					return 'left';
				}
			})
		</script>
	<?php 
				}elseif ($_SESSION['level']=="kepala_dinas") {
					# code...
					?>
					<div class="breadcrumbs" id="breadcrumbs">
					<ul class="breadcrumb">
						<li>
							<i class="icon-home home-icon"></i>
							<a href="home.php?page=pegawai">pegawai</a>

							<span class="divider">
								<i class="icon-angle-right arrow-icon"></i>
							</span>
						</li>
						<li class="active">pegawai</li>
					</ul><!--.breadcrumb-->
				</div>
				<div class="page-content">
					<div class="page-header position-relative">
						<h1>
							pegawai
							<small>
								<i class="icon-double-angle-right"></i>
								View
							</small>
						</h1>
					</div><!--/.page-header-->
						<div class="login-container">
			<?php 
if(isset($_GET['info_s'])){
	$display="block";
	$pemberitahuan=$_GET['info_s'];
}else{
	$display="none";
	$pemberitahuan="";
}
?>
<div class="alert alert-success" style="display:<?php echo $display;?>;"><?php echo $pemberitahuan; ?>
<button class="close" data-dismiss="alert">&times;</button>
</div>
</div>
					<br><br>
					<div class="row-fluid">
						<div class="span12">
							<!--PAGE CONTENT BEGINS-->
							<div class="form-inline">
										<a href="export_pegawai.php"><button class="btn btn-primary">Export pegawai</button></a>
					</div>
					<br>
							<div class="row-fluid">
								<div class="table-header">
									Data pegawai
								</div>

								<table id="sample-table-2" class="table table-striped table-bordered table-hover">
									<thead>
										<tr>
											<th class="center" style="width:1px;">NO</th>
											<th style="width:5px;">NIP</th>
											<th>Nama</th>
											<th>Gender</th>
											<th class="hidden-480">Alamat</th>
											<th class="hidden-480">Telepon</th>
											<th></th>
										</tr>
									</thead>
									<tbody>
									<?php 
									
									$query_pegawai=mysql_query("SELECT * FROM pegawai order by nama ASC");
									$no=1;
									while ($data_pegawai=mysql_fetch_array($query_pegawai)) {
										# code...
										echo '<tr>
											<td class="center">'; echo $no; echo '</td>
											<td>'; echo $data_pegawai['nip']; echo '</td>

											<td>
												';echo $data_pegawai['nama'];echo '
											</td>
											<td>
												';echo $data_pegawai['gender'];echo'
											</td>
											<td class="hidden-480">
												';echo $data_pegawai['alamat'];echo'
											</td>

											<td class="hidden-480">
												';echo $data_pegawai['telepon'];echo'
											</td>

											<td class="td-actions">
												<div class="hidden-phone visible-desktop action-buttons">
													<a class="blue" href="home.php?page=detail_pegawai&id=';echo  $data_pegawai['id_pegawai'] ;echo'">
														<i class="icon-zoom-in bigger-130"></i>
													</a>
												</div>

												<div class="hidden-desktop visible-phone">
													<div class="inline position-relative">
														<button class="btn btn-minier btn-yellow dropdown-toggle" data-toggle="dropdown">
															<i class="icon-caret-down icon-only bigger-120"></i>
														</button>
														<ul class="dropdown-menu dropdown-icon-only dropdown-yellow pull-right dropdown-caret dropdown-close">
															<li>
																<a href="home.php?page=detail_pegawai&id=';echo  $data_pegawai['id_pegawai'] ;echo'" class="tooltip-info" data-rel="tooltip" title="View">
																	<span class="blue">
																		<i class="icon-zoom-in bigger-120"></i>
																	</span>
																</a>
															</li>
													</div>
												</div>
											</td>
										</tr>';
										$no++;
									}
									 ?>
									</tbody>
								</table>
							</div>

							
									
								
							<!--PAGE CONTENT ENDS-->
						</div><!--/.span-->
					</div><!--/.row-fluid-->
				</div><!--/.page-content--> 
<!--basic scripts--> 

<!--[if IE]>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<![endif]--> 

<!--[if !IE]>--> 

<script type="text/javascript">
			window.jQuery || document.write("<script src='assets/js/jquery-2.0.3.min.js'>"+"<"+"/script>");
		</script> 

<!--<![endif]--> 

<!--[if IE]>
<script type="text/javascript">
 window.jQuery || document.write("<script src='assets/js/jquery-1.10.2.min.js'>"+"<"+"/script>");
</script>
<![endif]--> 

<!--page specific plugin scripts--> 

<script src="assets/js/jquery.dataTables.min.js"></script> 
<script src="assets/js/jquery.dataTables.bootstrap.js"></script> 

<!--ace scripts--> 

<!--inline scripts related to this page--> 

<script type="text/javascript">
			$(function() {
				var oTable1 = $('#sample-table-2').dataTable( {
				"aoColumns": [
			      { "bSortable": false },
			      null, null,null, null, null,
				  { "bSortable": false }
				] } );
				
				
				$('table th input:checkbox').on('click' , function(){
					var that = this;
					$(this).closest('table').find('tr > td:first-child input:checkbox')
					.each(function(){
						this.checked = that.checked;
						$(this).closest('tr').toggleClass('selected');
					});
						
				});
			
			
				$('[data-rel="tooltip"]').tooltip({placement: tooltip_placement});
				function tooltip_placement(context, source) {
					var $source = $(source);
					var $parent = $source.closest('table')
					var off1 = $parent.offset();
					var w1 = $parent.width();
			
					var off2 = $source.offset();
					var w2 = $source.width();
			
					if( parseInt(off2.left) < parseInt(off1.left) + parseInt(w1 / 2) ) return 'right';
					return 'left';
				}
			})
		</script>
					<?php
				}
				else{
  				echo "<script>alert('Anda Tidak Berhak Mengakses Laman Ini'); window.location = 'home.php'</script>";
				}

				 ?>