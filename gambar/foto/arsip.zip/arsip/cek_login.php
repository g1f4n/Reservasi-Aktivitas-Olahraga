<?php 
include 'koneksi.php';
function anti_injection($data){
  $filter = mysql_real_escape_string(stripslashes(strip_tags(htmlspecialchars($data,ENT_QUOTES))));
  return $filter;
}

$username = anti_injection($_POST['username']);
$password     = anti_injection(md5($_POST['password']));
// pastikan username dan password adalah berupa huruf atau angka.
if (!ctype_alnum($username) OR !ctype_alnum($password)){
  header("location:index.php?info_e=Maaf anda tidak diperkenankan melakukan ijection");
}else{
	$query_user=mysql_query("SELECT * FROM user where username='$username'");
	$cek_user=mysql_num_rows($query_user);
	$data_user=mysql_fetch_array($query_user);
	if ($cek_user==0) {
		# code...
		header("location:index.php?info_e=Username Tidak ada");
	}elseif($data_user['password']==$password){
		# code...
		session_start();
		$_SESSION['username']=$data_user['username'];
		$_SESSION['password']=$data_user['password'];
		$_SESSION['nama']=$data_user['nama'];
		$_SESSION['level']=$data_user['level'];
		header("location:home.php");
	}else{
		# code...
		header("location:index.php?info_e=password anda salah");
	}
}

 ?>