<?php 
				if ($_SESSION['level']=="admin") {
					# code...
					$id=$_GET['id'];
					$detail_surat_masuk=mysql_query("SELECT * FROM surat_masuk where id_surat='$id'");
					$data_surat_masuk=mysql_fetch_array($detail_surat_masuk);
				?>

<div class="breadcrumbs" id="breadcrumbs">
  <ul class="breadcrumb">
    <li> <i class="icon-home home-icon"></i> <a href="home.php?page=surat_masuk">Surat</a> <span class="divider"> <i class="icon-angle-right arrow-icon"></i> </span> </li>
    <li class="active">Surat Masuk</li>
  </ul>
  <!--.breadcrumb--> 
</div>
<div class="page-content">
  <div class="page-header position-relative">
    <h1> Surat Masuk <small> <i class="icon-double-angle-right"></i> Detail Surat Masuk </small> </h1>
  </div>
  <!--/.page-header-->
  <div class="login-container">
    <?php 
			if(isset($_GET['info_e'])){
			$display="block";
			$pemberitahuan=$_GET['info_e'];
		}else{
			$display="none";
			$pemberitahuan="";
}
?>
    <div class="alert alert-danger" style="display:<?php echo $display;?>;"><?php echo $pemberitahuan; ?>
      <button class="close" data-dismiss="alert">&times;</button>
    </div>
  </div>
  <div class="row-fluid">
    <div class="span12"> 
      <!--PAGE CONTENT BEGINS-->
      <div class="control-group">
        <label class="control-label">NO Surat</label>
        <div class="controls">
          <input class="input-xxlarge" type="text"  name="no_surat" value="<?php echo $data_surat_masuk['nomor_surat']; ?>" readonly />
        </div>
      </div>
      <div class="control-group">
        <label class="control-label">Uraian</label>
        <div class="controls">
          <textarea class="wysiwyg-editor input-xxlarge" name="uraian"  readonly><?php echo $data_surat_masuk['uraian']; ?></textarea>
        </div>
      </div>
      <div class="control-group">
        <label class="control-label">Keterangan</label>
        <div class="controls">
          <textarea class="wysiwyg-editor input-xxlarge" name="ket" readonly><?php echo $data_surat_masuk['ket']; ?></textarea>
        </div>
      </div>
      <div class="control-group">
        <label class="control-label">Tanggal</label>
        <div class="controls">
          <div class="row-fluid input-append">
            <input class="span10 date-picker" name="tanggal" id="id-date-picker-1" type="text" data-date-format="yyyy-mm-dd" value="<?php echo $data_surat_masuk['tanggal']; ?>" readonly />
            <span class="add-on"> <i class="icon-calendar"></i> </span> </div>
        </div>
      </div>
      <div class="form-actions"> <a class="btn btn-info" href="home.php?page=edit_surat_masuk&id=<?php echo $id; ?>"> <i class="icon-ok bigger-110"></i> Edit </a> &nbsp; &nbsp; &nbsp; <a class="btn" href="home.php?page=surat_masuk"> <i class="icon-undo bigger-110"></i> Kembali </a> </div>
    </div>
    <!--/.span--> 
  </div>
  <!--/.row-fluid--> 
</div>
<!--/.page-content-->

<?php 



				}elseif ($_SESSION['level']=="kepala_dinas") {
					# code...
					$id=$_GET['id'];
					$detail_surat_masuk=mysql_query("SELECT * FROM surat_masuk where id_surat='$id'");
					$data_surat_masuk=mysql_fetch_array($detail_surat_masuk);
				?>
<div class="breadcrumbs" id="breadcrumbs">
  <ul class="breadcrumb">
    <li> <i class="icon-home home-icon"></i> <a href="home.php?page=surat_masuk">Surat</a> <span class="divider"> <i class="icon-angle-right arrow-icon"></i> </span> </li>
    <li class="active">Surat Masuk</li>
  </ul>
  <!--.breadcrumb--> 
</div>
<div class="page-content">
  <div class="page-header position-relative">
    <h1> Surat Masuk <small> <i class="icon-double-angle-right"></i> Detail Surat Masuk </small> </h1>
  </div>
  <!--/.page-header-->
  <div class="login-container">
    <?php 
			if(isset($_GET['info_e'])){
			$display="block";
			$pemberitahuan=$_GET['info_e'];
		}else{
			$display="none";
			$pemberitahuan="";
}
?>
    <div class="alert alert-danger" style="display:<?php echo $display;?>;"><?php echo $pemberitahuan; ?>
      <button class="close" data-dismiss="alert">&times;</button>
    </div>
  </div>
  <div class="row-fluid">
    <div class="span12"> 
      <!--PAGE CONTENT BEGINS-->
      <div class="control-group">
        <label class="control-label">NO Surat</label>
        <div class="controls">
          <input class="input-xxlarge" type="text"  name="no_surat" value="<?php echo $data_surat_masuk['nomor_surat']; ?>" readonly />
        </div>
      </div>
      <div class="control-group">
        <label class="control-label">Uraian</label>
        <div class="controls">
          <textarea class="wysiwyg-editor input-xxlarge" name="uraian"  readonly><?php echo $data_surat_masuk['uraian']; ?></textarea>
        </div>
      </div>
      <div class="control-group">
        <label class="control-label">Keterangan</label>
        <div class="controls">
          <textarea class="wysiwyg-editor input-xxlarge" name="ket" readonly><?php echo $data_surat_masuk['ket']; ?></textarea>
        </div>
      </div>
      <div class="control-group">
        <label class="control-label">Tanggal</label>
        <div class="controls">
          <div class="row-fluid input-append">
            <input class="span10 date-picker" name="tanggal" id="id-date-picker-1" type="text" data-date-format="yyyy-mm-dd" value="<?php echo $data_surat_masuk['tanggal']; ?>" readonly />
            <span class="add-on"> <i class="icon-calendar"></i> </span> </div>
        </div>
      </div>
      <div class="form-actions"> <a class="btn btn-info" href="home.php?page=surat_masuk"> <i class="icon-undobigger-110"></i> Kembali </a> </div>
    </div>
    <!--/.span--> 
  </div>
  <!--/.row-fluid--> 
</div>
<!--/.page-content-->

<?php 
				}
				else{
  				echo "<script>alert('Anda Tidak Berhak Mengakses Laman Ini'); window.location = 'home.php'</script>";
				}

				 ?>
