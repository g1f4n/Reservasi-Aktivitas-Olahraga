
<div class="breadcrumbs" id="breadcrumbs">
  <ul class="breadcrumb">
    <li> <i class="icon-home home-icon"></i> <a href="#">Home</a> <span class="divider"> <i class="icon-angle-right arrow-icon"></i> </span> </li>
    <li class="active">Ganti Password</li>
  </ul>
  <!--.breadcrumb--> 
</div>
<div class="page-content">
  <div class="page-header position-relative">
    <h1> Ganti Password <small> <i class="icon-double-angle-right"></i> Edit </small> </h1>
  </div>
  <!--/.page-header-->
  
  <div class="row-fluid">
    <div class="span12"> 
      <!--PAGE CONTENT BEGINS-->
      <div class="login-container">
        <?php 
if(isset($_GET['info_s'])){
	$display="block";
	$pemberitahuan=$_GET['info_s'];
}else{
	$display="none";
	$pemberitahuan="";
}
?>
        <div class="alert alert-success" style="display:<?php echo $display;?>;"><?php echo $pemberitahuan; ?>
          <button class="close" data-dismiss="alert">&times;</button>
        </div>
      </div>
      <div class="login-container">
        <?php 
if(isset($_GET['info_e'])){
	$display="block";
	$pemberitahuan=$_GET['info_e'];
}else{
	$display="none";
	$pemberitahuan="";
}
?>
        <div class="alert alert-danger" style="display:<?php echo $display;?>;"><?php echo $pemberitahuan; ?>
          <button class="close" data-dismiss="alert">&times;</button>
        </div>
      </div>
      <form class="form-horizontal"  action="cek_ganti_pass.php" method="POST" />
      
      <div class="tabbable">
        <div id="edit-password" class="tab-pane">
          <div class="space-10"></div>
          <input type="hidden" name="uid" value="<?php echo $data['id_user']; ?>">
          <div class="control-group">
            <label class="control-label" >Password Lama</label>
            <div class="controls">
              <input type="password" name="password_lama" />
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" >Password Baru</label>
            <div class="controls">
              <input type="password" name="password_baru" />
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" >Ulangi Password</label>
            <div class="controls">
              <input type="password" name="ulangi_password" />
            </div>
          </div>
        </div>
      </div>
      <div class="form-actions">
        <button class="btn btn-info" type="submit" name="submit"> <i class="icon-ok bigger-110"></i> Save </button>
        &nbsp; &nbsp; &nbsp;
        <button class="btn" type="reset"> <i class="icon-undo bigger-110"></i> Reset </button>
      </div>
      </form>
      
      <!--PAGE CONTENT ENDS--> 
    </div>
    <!--/.span--> 
  </div>
  <!--/.row-fluid--> 
</div>
<!--/.page-content--> 

