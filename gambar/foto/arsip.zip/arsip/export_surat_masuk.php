<?php
include('koneksi.php');  
header("Content-Type: application/force-download");
header("Cache-Control: no-cache, must-revalidate");
$date = date('Y-m-d-H-i-s');
header("content-disposition: attachment; filename=laporan-data-surat-masuk-tanggal-$date.xls");
if(isset($_GET['dari'])){
  $dari=$_GET['dari'];
$sampai=$_GET['sampai'];
$query = mysql_query("SELECT * from surat_masuk where tanggal>='$dari' and tanggal <='$sampai' order by tanggal asc");
  }else{
  	$dari="-";
  	$sampai="-";
$query = mysql_query("SELECT * from surat_masuk order by tanggal asc");
  }
?>

<center><h2>Rekap Data Surat Masuk Dari : <?php echo $dari; ?> Sampa : <?php echo $sampai;?> </h2></center>

<table border='1'>
<h3>
<thead><tr>
<td width=52>No</td>
<td width=300>No Surat</td>
<td width=300>Uraian</td>
<td width=300>Keterangan</td>
<td width=150>Tanggal</td>
</tr></thead>
<h3><tbody>
<?php

$no=1;
while($data=mysql_fetch_array($query)){
?>

<tr>
    <td align="left"><?php echo $no; ?></td>
    <td align="left"><?php echo $data['nomor_surat']; ?></td>
    <td align="left"><?php echo $data['uraian']; ?></td>
    <td align="left"><?php echo $data['ket']; ?></td>
    <td align="left"><?php echo $data['tanggal']; ?></td>
<?php
$no++;
}?>
</tbody></h3></table>