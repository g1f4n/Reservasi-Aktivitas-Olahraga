<?php
include('koneksi.php');  
header("Content-Type: application/force-download");
header("Cache-Control: no-cache, must-revalidate");
$date = date('Y-m-d-H-i-s');
header("content-disposition: attachment; filename=laporan-data-Pegawai-tanggal-$date.xls");
?>

<center><h2>Rekap Data Pegawai</h2></center>
<table border='1'>
<h3>
<thead><tr>
<td width=52>No.</td>
<td width=150>NIP</td>
<td width=180>Nama</td>
<td width=150>Gender</td>
<td width=300>Alamat</td>
<td width=150>Telepon</td>
</tr></thead>
<h3><tbody>

<?php
$query = mysql_query("SELECT * from pegawai order by nama asc");
$no=1;
while($data=mysql_fetch_array($query)){
?>

<tr>
    <td align="left"><?php echo $no; ?></td>
    <td align="left"><?php echo $data['nip']; ?></td>
    <td align="left"><?php echo $data['nama']; ?></td>
    <td align="left"><?php echo $data['gender']; ?></td>
    <td align="left"><?php echo $data['alamat']; ?></td>
    <td align="left"><?php echo $data['telepon']; ?></td>
<?php
$no++;
}?>
</tbody></h3></table>