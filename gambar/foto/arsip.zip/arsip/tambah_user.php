<?php 
				if ($_SESSION['level']=="admin") {
					# code...
				?>

<div class="breadcrumbs" id="breadcrumbs">
  <ul class="breadcrumb">
    <li> <i class="icon-home home-icon"></i> <a href="home.php?page=user">User</a> <span class="divider"> <i class="icon-angle-right arrow-icon"></i> </span> </li>
    <li class="active">User</li>
  </ul>
  <!--.breadcrumb--> 
</div>
<div class="page-content">
  <div class="page-header position-relative">
    <h1> User <small> <i class="icon-double-angle-right"></i> Tambah User </small> </h1>
  </div>
  <!--/.page-header-->
  <div class="login-container">
    <?php 
			if(isset($_GET['info_e'])){
			$display="block";
			$pemberitahuan=$_GET['info_e'];
		}else{
			$display="none";
			$pemberitahuan="";
}
?>
    <div class="alert alert-danger" style="display:<?php echo $display;?>;"><?php echo $pemberitahuan; ?>
      <button class="close" data-dismiss="alert">&times;</button>
    </div>
  </div>
  <div class="row-fluid">
    <div class="span12"> 
      <!--PAGE CONTENT BEGINS-->
      <form class="form-horizontal" method="POST" action="aksi_tambah_admin.php" enctype="multipart/form-data" />
      
      <div class="control-group">
        <label class="control-label">Nama</label>
        <div class="controls">
          <input class="input-xxlarge" type="text"  name="nama" placeholder="Nama" />
        </div>
      </div>
      <div class="control-group">
        <label class="control-label">Username</label>
        <div class="controls">
          <input class="input-xxlarge" type="text"  name="username" placeholder="username" />
        </div>
      </div>
      <div class="control-group">
        <label class="control-label">Password</label>
        <div class="controls">
          <input class="input-xxlarge" type="password"  name="password" placeholder="password" />
        </div>
      </div>
      <div class="control-group">
        <label class="control-label">Alamat</label>
        <div class="controls">
          <input class="input-xxlarge" type="text" name="alamat" placeholder="Alamat" />
        </div>
      </div>
      <div class="control-group">
        <label class="control-label">Foto Profile</label>
        <div class="controls">
          <input class="input-xxlarge" type="file"  name="gambar" placeholder="Alamat" />
        </div>
      </div>
      <div class="control-group">
        <label class="control-label">Level</label>
        <div class="controls">
          <select name="level">
            <option>---</option>
            <option value="admin">Admin</option>
            <option value="kepala_dinas">Kepala Dinas</option>
          </select>
        </div>
      </div>
      <div class="form-actions">
        <button class="btn btn-info" name="submit" type="submit"> <i class="icon-ok bigger-110"></i> Submit </button>
        &nbsp; &nbsp; &nbsp;
        <button class="btn" type="reset"> <i class="icon-undo bigger-110"></i> Reset </button>
      </div>
      </form>
    </div>
    <!--/.span--> 
  </div>
  <!--/.row-fluid--> 
</div>
<!--/.page-content-->
<?php 
				}else{
  				echo "<script>alert('Anda Tidak Berhak Mengakses Laman Ini'); window.location = 'home.php'</script>";
				}

				 ?>
