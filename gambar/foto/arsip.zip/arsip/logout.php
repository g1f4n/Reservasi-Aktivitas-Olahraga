<?php
  session_start();
  session_destroy();
  echo "<script>alert('Anda telah keluar dari halaman arsip surat'); window.location = 'index.php'</script>";
?>