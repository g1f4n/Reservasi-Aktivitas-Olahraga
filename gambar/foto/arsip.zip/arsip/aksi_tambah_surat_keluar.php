<?php
session_start(); 
if ($_SESSION['level']=="admin") {
	if (isset($_POST['submit'])!="" and $_POST['no_surat']!="" and $_POST['uraian']!="" and $_POST['tujuan']!="" and $_POST['ket']!="" and $_POST['tanggal']!="") {
		# code...
		include 'koneksi.php';
		$no_surat=$_POST['no_surat'];
		$uraian=$_POST['uraian'];
		$tujuan=$_POST['tujuan'];
		$ket=$_POST['ket'];
		$tanggal=$_POST['tanggal'];
		$query_tambah=mysql_query("INSERT INTO surat_keluar(nomor_surat,uraian,tujuan,ket,tanggal)
		VALUES ('$no_surat','$uraian','$tujuan','$ket','$tanggal')");
		header('location:home.php?page=surat_keluar&info_s=tambah surat keluar Berhasil');
	}elseif (isset($_POST['usubmit'])!="" and $_POST['uno_surat']!="" and $_POST['uuraian']!="" and $_POST['utujuan']!="" and $_POST['uket']!="" and $_POST['utanggal']!="") {
		# code...
		include 'koneksi.php';
		$uid=$_POST['uid'];
		$uno_surat=$_POST['uno_surat'];
		$uuraian=$_POST['uuraian'];
		$utujuan=$_POST['utujuan'];
		$uket=$_POST['uket'];
		$utanggal=$_POST['utanggal'];
		$query_update=mysql_query("UPDATE surat_keluar SET nomor_surat='$uno_surat',uraian='$uuraian',tujuan='$utujuan',ket='$uket',tanggal='$utanggal' where id_surat='$uid' ");
		header('location:home.php?page=surat_keluar&info_s=Update surat keluar Berhasil');
	}elseif (isset($_POST['usubmit'])) {
		# code...
		$uid=$_POST['uid'];
		header("location:home.php?page=edit_surat_keluar&id=$uid&info_e=Data Yang Anda input Tidak Lengkap");
	}
	else{
		header('location:home.php?page=tambah_surat_keluar&info_e=Data Yang Anda input Tidak Lengkap');
	}

	}else{
  				echo "<script>alert('Anda Tidak Berhak Mengakses Laman Ini'); window.location = 'home.php'</script>";
	}

 ?>