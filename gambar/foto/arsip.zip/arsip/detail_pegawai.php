<?php 
				if ($_SESSION['level']=="admin") {
					# code...
					$id=$_GET['id'];
					$detail_pegawai=mysql_query("SELECT * FROM pegawai where id_pegawai='$id'");
					$data_pegawai=mysql_fetch_array($detail_pegawai);
				?>

<div class="breadcrumbs" id="breadcrumbs">
  <ul class="breadcrumb">
    <li> <i class="icon-home home-icon"></i> <a href="home.php?page=pegawai">Pegawai</a> <span class="divider"> <i class="icon-angle-right arrow-icon"></i> </span> </li>
    <li class="active">Pegawai</li>
  </ul>
  <!--.breadcrumb--> 
</div>
<div class="page-content">
  <div class="page-header position-relative">
    <h1> Pegawai <small> <i class="icon-double-angle-right"></i> Detail Pegawai </small> </h1>
  </div>
  <!--/.page-header-->
  <div class="login-container">
    <?php 
			if(isset($_GET['info_e'])){
			$display="block";
			$pemberitahuan=$_GET['info_e'];
		}else{
			$display="none";
			$pemberitahuan="";
}
?>
    <div class="alert alert-danger" style="display:<?php echo $display;?>;"><?php echo $pemberitahuan; ?>
      <button class="close" data-dismiss="alert">&times;</button>
    </div>
  </div>
  <div class="row-fluid">
    <div class="span12"> 
      <!--PAGE CONTENT BEGINS-->
      <div class="control-group">
        <label class="control-label">NIP</label>
        <div class="controls">
          <input class="input-xxlarge" type="text"  name="no_pegawai" value="<?php echo $data_pegawai['nip']; ?>" readonly />
        </div>
      </div>
      <div class="control-group">
        <label class="control-label">nama</label>
        <div class="controls">
          <input class="input-xxlarge" type="text"  name="nama" value="<?php echo $data_pegawai['nama']; ?>" readonly />
        </div>
      </div>
      <div class="control-group">
        <label class="control-label">Gender</label>
        <div class="controls">
        <input class="input-xxlarge" type="text"  name="gender" value="<?php echo $data_pegawai['gender']; ?>" readonly />
        </div>
      </div>
      <div class="control-group">
        <label class="control-label">Alamat</label>
        <div class="controls">
          <textarea class="wysiwyg-editor input-xxlarge" name="alamat" readonly><?php echo $data_pegawai['alamat']; ?></textarea>
        </div>
      </div>
      <div class="control-group">
        <label class="control-label">Telepon</label>
        <div class="controls">
        <input class="input-xxlarge" type="text"  name="telepon" value="<?php echo $data_pegawai['telepon']; ?>" readonly />
        </div>
      </div>
      <div class="form-actions"> <a class="btn btn-info" href="home.php?page=edit_pegawai&id=<?php echo $id; ?>"> <i class="icon-ok bigger-110"></i> Edit </a> &nbsp; &nbsp; &nbsp; <a class="btn" href="home.php?page=pegawai"> <i class="icon-undo bigger-110"></i> Kembali </a> </div>
    </div>
    <!--/.span--> 
  </div>
  <!--/.row-fluid--> 
</div>
<!--/.page-content-->

<?php 



				}elseif ($_SESSION['level']=="kepala_dinas") {
					# code...
					$id=$_GET['id'];
					$detail_pegawai=mysql_query("SELECT * FROM pegawai where id_pegawai='$id'");
					$data_pegawai=mysql_fetch_array($detail_pegawai);
				?>
<div class="breadcrumbs" id="breadcrumbs">
  <ul class="breadcrumb">
    <li> <i class="icon-home home-icon"></i> <a href="home.php?page=pegawai">Pegawai</a> <span class="divider"> <i class="icon-angle-right arrow-icon"></i> </span> </li>
    <li class="active">Pegawai</li>
  </ul>
  <!--.breadcrumb--> 
</div>
<div class="page-content">
  <div class="page-header position-relative">
    <h1> Pegawai  <small> <i class="icon-double-angle-right"></i> Detail Pegawai </small> </h1>
  </div>
  <!--/.page-header-->
  <div class="login-container">
    <?php 
			if(isset($_GET['info_e'])){
			$display="block";
			$pemberitahuan=$_GET['info_e'];
		}else{
			$display="none";
			$pemberitahuan="";
}
?>
    <div class="alert alert-danger" style="display:<?php echo $display;?>;"><?php echo $pemberitahuan; ?>
      <button class="close" data-dismiss="alert">&times;</button>
    </div>
  </div>
  <div class="row-fluid">
    <div class="span12"> 
      <!--PAGE CONTENT BEGINS-->
      <div class="control-group">
        <label class="control-label">NIP</label>
        <div class="controls">
          <input class="input-xxlarge" type="text"  name="no_pegawai" value="<?php echo $data_pegawai['nip']; ?>" readonly />
        </div>
      </div>
      <div class="control-group">
        <label class="control-label">nama</label>
        <div class="controls">
          <input class="input-xxlarge" type="text"  name="nama" value="<?php echo $data_pegawai['nama']; ?>" readonly />
        </div>
      </div>
      <div class="control-group">
        <label class="control-label">Gender</label>
        <div class="controls">
        <input class="input-xxlarge" type="text"  name="gender" value="<?php echo $data_pegawai['gender']; ?>" readonly />
        </div>
      </div>
      <div class="control-group">
        <label class="control-label">Alamat</label>
        <div class="controls">
          <textarea class="wysiwyg-editor input-xxlarge" name="alamat" readonly><?php echo $data_pegawai['alamat']; ?></textarea>
        </div>
      </div>
      <div class="control-group">
        <label class="control-label">Telepon</label>
        <div class="controls">
        <input class="input-xxlarge" type="text"  name="telepon" value="<?php echo $data_pegawai['telepon']; ?>" readonly />
        </div>
      </div>
      <div class="form-actions"> <a class="btn btn-info" href="home.php?page=pegawai"> <i class="icon-undobigger-110"></i> Kembali </a> </div>
    </div>
    <!--/.span--> 
  </div>
  <!--/.row-fluid--> 
</div>
<!--/.page-content-->

<?php 
				}
				else{
  				echo "<script>alert('Anda Tidak Berhak Mengakses Laman Ini'); window.location = 'home.php'</script>";
				}

				 ?>
