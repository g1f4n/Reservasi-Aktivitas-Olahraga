<?php
	if(isset($_POST['submit'])){
	function anti_injection($data){
  	$filter = mysql_real_escape_string(stripslashes(strip_tags(htmlspecialchars($data,ENT_QUOTES))));
  	return $filter;
	}
	session_start();
	include 'koneksi.php';
	$uid_user=$_POST['uid'];
	$password_lama=anti_injection(md5($_POST['password_lama']));
	$password_baru=anti_injection($_POST['password_baru']);
	$ulangi_password=anti_injection($_POST['ulangi_password']);
	$password=anti_injection(md5($_POST['password_lama']));
	$update_password=anti_injection(md5($_POST['password_baru']));
	if (!ctype_alnum($password_baru) OR !ctype_alnum($password_lama) OR !ctype_alnum($ulangi_password)){
  header("location:home.php?page=ganti_password&info_e=Maaf anda tidak diperkenankan melakukan ijection");
}else{
	$query_pass=mysql_query("SELECT * from user where username='$_SESSION[username]' and password='$password' and id_user='$uid_user'");
	$cek_pass=mysql_num_rows($query_pass);
	if($password_baru!=$ulangi_password){
		header("location:home.php?page=ganti_password&info_e=Password Baru dan ulangi password tidak sama"." ". $password_baru ." "."dan"." ". $ulangi_password);
	}elseif($cek_pass >= 1 and $password_baru==$ulangi_password){
		$update=mysql_query("UPDATE user SET password='$update_password' where id_user='$uid_user'");
		header("location:home.php?page=ganti_password&info_s=Password Berhasil di Update");
	}else{
		header("location:home.php?page=ganti_password&info_e=Password lama Tidak sama");
	}
	}
	}
	?>
