<?php
session_start(); 
if ($_SESSION['level']=="admin") {
					# code...
	if (isset($_POST['submit'])!="" and $_POST['nama']!="" and $_POST['username']!="" and $_POST['password']!="" and $_POST['alamat']!=""
		and $_POST['level']!="") {
		# code...
		include 'koneksi.php';
		$nama=$_POST['nama'];
		$username=$_POST['username'];
		$password=md5($_POST['password']);
		$alamat=$_POST['alamat'];
		$level=$_POST['level'];
		$acak=date("Y-m-d-H-i-s-");
		$file_gambar=$_FILES['gambar']['name'];
		$unik=$acak.$file_gambar;
		$query_cek_user=mysql_query("SELECT * FROM user where username='$username'");
		$cek_user=mysql_num_rows($query_cek_user);
		if ($cek_user==0) {
			# code...
		$query_tambah=mysql_query("INSERT INTO user(nama_user,alamat,gambar,username,password,level)
		VALUES ('$nama','$alamat','$unik','$username','$password','$level')");
		chmod($unik, 777);
		move_uploaded_file($_FILES['gambar']['tmp_name'], "user/".$unik);
		header('location:home.php?page=user&info_s=tambah user Berhasil');
		}else{
		header("location:home.php?page=tambah_user&info_e=Username sudah di gunakan");
		}
		
	}else{
		header('location:home.php?page=tambah_user&info_e=Data Yang Anda input Tidak Lengkap');
	}
	}else{
  				echo "<script>alert('Anda Tidak Berhak Mengakses Laman Ini'); window.location = 'home.php'</script>";
				}
?>