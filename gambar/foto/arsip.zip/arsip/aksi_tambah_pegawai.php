<?php
session_start(); 
if ($_SESSION['level']=="admin") {
					# code...
	if (isset($_POST['submit'])!="" and $_POST['nip']!="" and $_POST['nama']!="" and $_POST['gender']!="" and $_POST['alamat']!=""
		and $_POST['telepon']!="") {
		# code...
		include 'koneksi.php';
		$nip=$_POST['nip'];
		$nama=$_POST['nama'];
		$gender=$_POST['gender'];
		$alamat=$_POST['alamat'];
		$telepon=$_POST['telepon'];
		$query_cek_pegawai=mysql_query("SELECT * FROM pegawai where nip='$nip'");
		$cek_pegawai=mysql_num_rows($query_cek_pegawai);
		if ($cek_pegawai==0) {
			# code...
		$query_tambah=mysql_query("INSERT INTO pegawai(nip,nama,gender,alamat,telepon)
		VALUES ('$nip','$nama','$gender','$alamat','$telepon')");
		header('location:home.php?page=pegawai&info_s=tambah pegawai Berhasil');
		}else{
		header("location:home.php?page=tambah_pegawai&info_e=NIP pegawai sudah di gunakan");
		}
		
	}elseif (isset($_POST['usubmit'])!="" and $_POST['unip']!="" and $_POST['unama']!="" and $_POST['ugender']!="" and $_POST['ualamat']!=""
		and $_POST['utelepon']!="") {
		# code...
		include 'koneksi.php';
		$uid=$_POST['uid'];
		$unip=$_POST['unip'];
		$unama=$_POST['unama'];
		$ugender=$_POST['ugender'];
		$ualamat=$_POST['ualamat'];
		$utelepon=$_POST['utelepon'];
			# code...
		$query_update=mysql_query("UPDATE pegawai SET nip='$unip',nama='$unama',gender='$ugender',alamat='$ualamat',telepon='$utelepon' where id_pegawai='$uid' ");
		header('location:home.php?page=pegawai&info_s=Edit pegawai Berhasil');
	}elseif (isset($_POST['usubmit'])) {
		# code...
		$uid=$_POST['uid'];
		header("location:home.php?page=edit_pegawai&id=$uid&info_e=Data Yang Anda input Tidak Lengkap");
	}else{
		header('location:home.php?page=tambah_pegawai&info_e=Data Yang Anda input Tidak Lengkap');
	}
}else{
  				echo "<script>alert('Anda Tidak Berhak Mengakses Laman Ini'); window.location = 'home.php'</script>";
	}
?>